package car_shop;

public interface Car {

    Integer TIRES = 4;
    String getModel();
    String getColor();
    int getHorsePower();

}
