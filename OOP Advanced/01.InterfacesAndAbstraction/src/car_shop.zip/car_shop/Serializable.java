package car_shop;

public interface Serializable {
}
