package warriors.models;

public interface Attacker {
    void attack();
    void setTarget(Target target);
}
