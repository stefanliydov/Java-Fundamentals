package warriors.models;

import warriors.observer.Subject;

public interface ObservableTarget extends Target, Subject {

}
