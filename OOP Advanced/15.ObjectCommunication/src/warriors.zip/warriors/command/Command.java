package warriors.command;

public interface Command {
    void execute();
}
