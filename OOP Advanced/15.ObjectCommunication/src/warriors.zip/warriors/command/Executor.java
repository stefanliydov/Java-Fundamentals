package warriors.command;

public interface Executor {
    void executeCommand(Command command);
}

