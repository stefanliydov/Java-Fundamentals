package warriors.observer;

public interface Observer {
    void update(int reward);
}
