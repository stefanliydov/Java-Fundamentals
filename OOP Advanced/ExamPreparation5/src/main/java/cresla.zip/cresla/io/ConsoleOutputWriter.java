package cresla.io;

import cresla.interfaces.OutputWriter;

public class ConsoleOutputWriter implements OutputWriter {

    @Override
    public void write(String output) {

    }

    @Override
    public void writeLine(String output) {

    }
}
