package cresla.io;

import cresla.interfaces.InputReader;

public class ConsoleInputReader implements InputReader {

    @Override
    public String readLine() {
        return null;
    }
}
