package cresla.models.modules;

import cresla.models.modules.BaseEnergyModule;

public class CryogenRod extends BaseEnergyModule {

    @Override
    public int getEnergyOutput() {
        return 0;
    }

    @Override
    public int getId() {
        return 0;
    }
}
