package cresla.models.modules;

import cresla.interfaces.AbsorbingModule;
import cresla.models.modules.BaseModule;

public abstract class BaseAbsorbingModule extends BaseModule implements AbsorbingModule {

}
