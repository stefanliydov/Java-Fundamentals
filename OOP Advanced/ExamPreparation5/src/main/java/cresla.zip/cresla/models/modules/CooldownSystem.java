package cresla.models.modules;

import cresla.models.modules.BaseAbsorbingModule;

public class CooldownSystem extends BaseAbsorbingModule {

    @Override
    public int getHeatAbsorbing() {
        return 0;
    }

    @Override
    public int getId() {
        return 0;
    }
}
