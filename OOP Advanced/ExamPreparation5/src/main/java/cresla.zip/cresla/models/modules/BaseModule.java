package cresla.models.modules;

import cresla.interfaces.Module;

public abstract class BaseModule implements Module {

    protected BaseModule() {

    }
}
