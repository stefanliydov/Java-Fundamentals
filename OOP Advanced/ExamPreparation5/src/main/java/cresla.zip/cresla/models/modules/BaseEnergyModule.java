package cresla.models.modules;

import cresla.interfaces.EnergyModule;
import cresla.models.modules.BaseModule;

public abstract class BaseEnergyModule extends BaseModule implements EnergyModule {

}
