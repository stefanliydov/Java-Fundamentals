package hero_inventory_tests;

import hell.entities.miscellaneous.HeroInventory;
import hell.entities.miscellaneous.items.CommonItem;
import hell.interfaces.Inventory;
import hell.interfaces.Item;
import hell.interfaces.Recipe;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.lang.reflect.Field;
import java.util.HashMap;

public class HeroInventoryTests {


    private Inventory inventory;
    private Item item1;
    private Item item2;
    private Item item3;
    private Recipe recipe1;
    private Recipe recipe2;

    @Before
    public void beforeTest() throws NoSuchFieldException, IllegalAccessException {
        this.inventory = new HeroInventory();

        this.item1 = Mockito.mock(Item.class);
        this.item2 = Mockito.mock(Item.class);
        this.item3 = Mockito.mock(Item.class);
        this.recipe1 = Mockito.mock(Recipe.class);
        this.recipe2 = Mockito.mock(Recipe.class);

        Field commonItemsField = this.inventory.getClass().getDeclaredField("commonItems");
        commonItemsField.setAccessible(true);

        HashMap<String, Item> commonItems = (HashMap<String, Item>) commonItemsField.get(this.inventory);


        Mockito.when(item1.getStrengthBonus()).thenReturn(2_000_000_000);
        Mockito.when(item1.getAgilityBonus()).thenReturn(2_000_000_000);
        Mockito.when(item1.getIntelligenceBonus()).thenReturn(2_000_000_000);
        Mockito.when(item1.getHitPointsBonus()).thenReturn(2_000_000_000);
        Mockito.when(item1.getDamageBonus()).thenReturn(2_000_000_000);

        Mockito.when(item2.getStrengthBonus()).thenReturn(2_000_000_000);
        Mockito.when(item2.getAgilityBonus()).thenReturn(2_000_000_000);
        Mockito.when(item2.getIntelligenceBonus()).thenReturn(2_000_000_000);
        Mockito.when(item2.getHitPointsBonus()).thenReturn(2_000_000_000);
        Mockito.when(item2.getDamageBonus()).thenReturn(2_000_000_000);

        Mockito.when(item3.getStrengthBonus()).thenReturn(2_000_000_000);
        Mockito.when(item3.getAgilityBonus()).thenReturn(2_000_000_000);
        Mockito.when(item3.getIntelligenceBonus()).thenReturn(2_000_000_000);
        Mockito.when(item3.getHitPointsBonus()).thenReturn(2_000_000_000);
        Mockito.when(item3.getDamageBonus()).thenReturn(2_000_000_000);

        commonItems.put("item1",item1);
        commonItems.put("item2",item2);
        commonItems.put("item3",item3);

    }
    //Test getStats methods
    @Test
    public void testGetTotalStrenght(){
        Assert.assertEquals(this.inventory.getTotalStrengthBonus(),6_000_000_000L);
    }
    @Test
    public void testGetTotalStrenghtWithWrongResult(){
        Assert.assertNotEquals(this.inventory.getTotalStrengthBonus(),5_000_000_000L);
    }

    @Test
    public void testGetTotalAgility(){
        Assert.assertEquals(this.inventory.getTotalAgilityBonus(),6_000_000_000L);
    }
    @Test
    public void testGetTotalAgilitytWithWrongResult(){
        Assert.assertNotEquals(this.inventory.getTotalAgilityBonus(),5_000_000_000L);
    }


    @Test
    public void testGetTotalIntelligence(){
        Assert.assertEquals(this.inventory.getTotalIntelligenceBonus(),6_000_000_000L);
    }
    @Test
    public void testGetTotalIntelligenceWithWrongResult(){
        Assert.assertNotEquals(this.inventory.getTotalIntelligenceBonus(),5_000_000_000L);
    }


    @Test
    public void testGetTotalHitPoints(){
        Assert.assertEquals(this.inventory.getTotalHitPointsBonus(),6_000_000_000L);
    }
    @Test
    public void testGetTotalHitPointstWithWrongResult(){
        Assert.assertNotEquals(this.inventory.getTotalHitPointsBonus(),5_000_000_000L);
    }


    @Test
    public void testGetTotalDamage(){
        Assert.assertEquals(this.inventory.getTotalDamageBonus(),6_000_000_000L);
    }
    @Test
    public void testGetTotalDamageWithWrongResult(){
        Assert.assertNotEquals(this.inventory.getTotalDamageBonus(),5_000_000_000L);
    }

    //Test add common item
    @Test
    public void addCommonItem(){
        this.inventory.addCommonItem(new CommonItem("Axe",3,10,3,3,3));
        Assert.assertEquals(this.inventory.getTotalStrengthBonus(),6_000_000_003L);
        Assert.assertEquals(this.inventory.getTotalAgilityBonus(),6_000_000_010L);
    }

}
