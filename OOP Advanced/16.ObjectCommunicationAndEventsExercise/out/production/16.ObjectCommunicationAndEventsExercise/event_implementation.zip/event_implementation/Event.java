package event_implementation;

public class Event extends EventObject {

}
