package event_implementation;

public class EventObject {

}
