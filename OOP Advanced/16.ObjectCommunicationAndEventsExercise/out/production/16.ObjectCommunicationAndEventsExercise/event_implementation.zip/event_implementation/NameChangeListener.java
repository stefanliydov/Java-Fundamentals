package event_implementation;

public interface NameChangeListener {
    void handleChangedName(NameChange event);
}
