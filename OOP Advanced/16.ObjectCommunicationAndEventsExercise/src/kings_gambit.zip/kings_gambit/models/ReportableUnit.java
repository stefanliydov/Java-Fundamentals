package kings_gambit.models;

public interface ReportableUnit {
}
