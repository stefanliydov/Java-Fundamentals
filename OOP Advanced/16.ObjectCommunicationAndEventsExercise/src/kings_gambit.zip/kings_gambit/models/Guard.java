package kings_gambit.models;

public interface Guard {
    public String toString();
}
