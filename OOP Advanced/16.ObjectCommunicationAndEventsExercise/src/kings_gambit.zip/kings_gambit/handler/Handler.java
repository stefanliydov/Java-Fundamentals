package kings_gambit.handler;

import kings_gambit.models.ReportableUnit;

public class Handler {

    public void report(ReportableUnit report){
        System.out.println(report);
    }
}
