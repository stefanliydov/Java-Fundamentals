package collection_hierarchy;

public interface IAddRemoveCollection {
    int add(String el);
    String remove();
}
