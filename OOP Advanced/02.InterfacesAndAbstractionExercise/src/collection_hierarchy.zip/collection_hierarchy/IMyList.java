package collection_hierarchy;

public interface IMyList {
    int add(String el);
    String remove();
    int used();
}
