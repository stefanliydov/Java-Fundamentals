package collection_hierarchy;

public interface IAddCollection {
    int add(String el);
}
