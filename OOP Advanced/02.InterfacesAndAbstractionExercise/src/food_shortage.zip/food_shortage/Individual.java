package food_shortage;

public interface Individual {

    String getBirthday();
}
