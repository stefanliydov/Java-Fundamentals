package birthday_celebrations;

public interface Individual {

    String getBirthday();
}
