package birthday_celebrations;

public class Pet implements Individual {

    private String name;
    private String birthday;

    public Pet(String name, String birthday) {
        this.name = name;
        this.birthday = birthday;
    }

    @Override
    public String getBirthday() {
        return null;
    }
}
