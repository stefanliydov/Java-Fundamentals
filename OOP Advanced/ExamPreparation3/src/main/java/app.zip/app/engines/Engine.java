package app.engines;

import app.waste_disposal.contracts.ConsoleReader;
import app.waste_disposal.contracts.ConsoleWriter;

public class Engine {

}
