package app.waste_disposal.contracts;

import java.util.Scanner;

public interface ConsoleReader {

    public String readLine();
}
