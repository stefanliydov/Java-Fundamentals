package app.waste_disposal.contracts;

public interface ConsoleWriter {
    public void writeLine(String string);
}
