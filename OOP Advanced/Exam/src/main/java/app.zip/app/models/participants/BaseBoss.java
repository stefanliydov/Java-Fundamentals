package app.models.participants;

import app.contracts.Targetable;

public abstract class BaseBoss implements Targetable {
    protected BaseBoss() {
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
