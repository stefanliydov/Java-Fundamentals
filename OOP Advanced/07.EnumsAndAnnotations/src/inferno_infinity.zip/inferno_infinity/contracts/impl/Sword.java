package inferno_infinity.contracts.impl;

import inferno_infinity.enums.WeaponTypes;

public class Sword extends BaseWeapon {


    public Sword(String name, WeaponTypes weapon) {
        super(name, weapon);
    }
}
