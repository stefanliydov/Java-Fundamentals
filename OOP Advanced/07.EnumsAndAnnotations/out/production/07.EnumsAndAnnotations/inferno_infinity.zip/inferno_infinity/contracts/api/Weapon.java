package inferno_infinity.contracts.api;

import inferno_infinity.enums.GemTypes;

import java.util.Comparator;

public interface Weapon extends Comparable<Weapon> {
    public void addGem(GemTypes gem, int index);
    public void removeGem(int index);
    double getLevel();
    public String printBiggerStats();
    public void addBonusStats();
}
