package inferno_infinity.contracts.impl;

import inferno_infinity.enums.WeaponTypes;

public class Knife extends BaseWeapon {


    public Knife(String name, WeaponTypes weapon) {
        super(name, weapon);
    }
}
