package inferno_infinity.contracts.impl;

import inferno_infinity.enums.GemTypes;
import inferno_infinity.enums.WeaponTypes;

public class Axe extends BaseWeapon {


    public Axe(String name, WeaponTypes weapon) {
        super(name, weapon);
    }

}
