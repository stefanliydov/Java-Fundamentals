package bg.softuni.models;

public interface Boss {
}
