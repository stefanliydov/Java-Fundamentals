package bg.softuni.enums;

public enum EmergencyLevel {
    Minor,
    Major,
    Disaster
}
