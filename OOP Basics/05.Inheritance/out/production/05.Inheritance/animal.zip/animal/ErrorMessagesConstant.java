package animal;

public class ErrorMessagesConstant {

    public static final String ERROR_MESSAGE = "Invalid input!";

    private ErrorMessagesConstant(){

    }
}
