package SingleInheritance;

public class Food {

}
