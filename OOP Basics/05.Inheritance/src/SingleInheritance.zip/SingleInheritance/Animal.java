package SingleInheritance;

import java.util.ArrayList;

public class Animal {

   protected ArrayList<Food> foodEaten;

   public final void eat(Food food){

   }
   public  void eatAll(Food food){

   }


}
