package SingleInheritance;

public class Predator {

    private int health;

    public void feed(Food food){

    }

}
