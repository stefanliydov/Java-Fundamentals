package system_split.models;



public class Main {

    public static void main(String[] args) {
    }
}
