package vehicle;

public class Truck extends  Vehicle {


    public Truck(double fuel, double litersPerKm) {
        super(fuel, litersPerKm+1.6);
    }

    @Override
    protected void drive(double km) {
        double fuel = super.getLitersPerKm()*km;
        if(fuel> super.getFuel()){
            throw new IllegalArgumentException("Truck needs refueling");
        }
        System.out.println(String.format("Truck travelled %s km",Vehicle.DECIMAL_FORMAT.format(km)));
        super.setFuel(-fuel);
    }

    @Override
    protected void refuel(double fuel) {
        super.setFuel(fuel*0.95);
    }
}
