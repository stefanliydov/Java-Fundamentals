package vehicle;

public class Car extends Vehicle {


    public Car(double fuel, double litersPerKm) {
        super(fuel, litersPerKm+0.9);
    }

    @Override
    protected void drive(double km) {
        double fuel = super.getLitersPerKm()*km;
        if(fuel> super.getFuel()){
            throw new IllegalArgumentException("Car needs refueling");
        }
        System.out.println(String.format("Car travelled %s km",Vehicle.DECIMAL_FORMAT.format(km)));
        super.setFuel(-fuel);
    }

    @Override
    protected void refuel(double fuel) {
        super.setFuel(fuel);
    }
}
