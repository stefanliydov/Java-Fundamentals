package vehicle;

import java.text.DecimalFormat;

abstract class Vehicle {

     private static final String FORMAT = "#.##";
     protected static final DecimalFormat DECIMAL_FORMAT = new DecimalFormat(FORMAT);

    private double fuel;
     private double litersPerKm;

      Vehicle(double fuel, double litersPerKm) {
         this.fuel = fuel;
         this.litersPerKm = litersPerKm;
     }

     protected abstract void drive(double km);

    protected abstract void refuel(double fuel);

      double getFuel() {
         return this.fuel;
     }

      double getLitersPerKm() {
         return this.litersPerKm;
     }

      void setFuel(double fuel) {
         this.fuel += fuel;
     }
 }
